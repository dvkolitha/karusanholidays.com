<?php
/*
 * Element tz-feature-item
 * */

function aventura_carousel_slide($atts, $content = null)
{
    $tz_image = $tz_image_size = $tz_click_action = $tz_custom_links = $tz_link_target = '';
    $title = $tz_button = $title_video = $tz_link = $meta = '';
    extract(shortcode_atts(array(
            'meta' => '',
        'tz_image' => '',
        'tz_image_size' => '',
        'tz_click_action' => 'none',
        'tz_custom_links' => '',
        'tz_link_target' => 'same',
        'title' => '',
        'title_video' => '',
        'tz_button' => '',
        'tz_link' => '',


    ), $atts));
    ob_start();
    $meta = vc_param_group_parse_atts($meta);
    $content = wpb_js_remove_wpautop($content, true);

    wp_enqueue_script('lity', get_template_directory_uri() . '/js/lity.js', array(), false, true);
    wp_enqueue_style('lity', get_template_directory_uri() . '/css/lity.css', false);


    wp_enqueue_script('owl-carousel');
    wp_enqueue_style('owl-carousel');

    if ('link_image' === $tz_click_action) {
        wp_enqueue_script('jquery.prettyPhoto');
        wp_enqueue_style('prettyPhoto');
    }

    $images = explode(',', $tz_image);
    $pretty_rand = 'pretty' === $tz_click_action ? ' data-rel="prettyPhoto[rel-' . get_the_ID() . '-' . rand() . ']"' : '';

    if ('custom' === $tz_click_action) {
        $custom_links = vc_value_from_safe($tz_custom_links);
        $custom_links = explode(',', $tz_custom_links);
    }

    $i = -1;
    ?>
    <div class="tzElement_Image_slide">
        <div class="image-slider owl-carousel">

            <?php
            $i = 0;
            foreach ($meta as $meta_item) {

                $i++;
                $img = wp_get_attachment_image_src($meta_item['tz_image'],'tz_image_size');

//                $post_thumbnail = wpb_getImageBySize(array(
//                    'attach_id' => $attach_id,
//                    'thumb_size' => $tz_image_size,
//                ));
//                $thumbnail = $post_thumbnail['thumbnail'];
                ?>

                <div class="tzImage_Slide_Item" data-dot="<span>0<?php echo $i; ?></span>">

                    <div class="container">
                        <h3 class="animated fadeInUp"><?php echo esc_html__($meta_item['title']); ?></h3>
                        <div class="readmore">
                            <a href="<?php echo esc_html($meta_item['tz_link']); ?>" class="view-more"><span class="icon-arrow-right"></span>
                            <div class="discover"><?php echo esc_html__($meta_item['tz_button']); ?></div>
                            </a>
                        </div>

                        <div class="video">
                            <div class="play">
                                <a href="<?php echo esc_html__($content); ?>" data-lity>
                                    <i class="fa fa-play" aria-hidden="true"></i>
                                </a>
                            </div>
                            <h5><?php echo balanceTags($title_video); ?></h5>
                        </div>
                    </div>
                    <img src="<?php echo esc_url($img[0])?>" alt="">
                </div>
            <?php } ?>
        </div>

        <script type="text/javascript">
            jQuery(document).ready(function () {
                "use strict";

                jQuery('.image-slider').each(function () {

                    jQuery(this).owlCarousel({
                        nav: false,
                        navText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"],
                        dots: true,
                        animateIn: 'fadeIn',
                        animateOut: 'fadeOut',
                        smartSpeed:450,
                        slideSpeed : 1000,
                        loop: true,
                        autoplay:true,
                        autoplayTimeout:5000,
                        paginationSpeed : 1000,
                        dotsData: true,
                        responsive:{
                            0:{
                                items: 1
                            },
                            600:{
                                items: 1
                            },
                            992:{
                                items: 1
                            },
                            1200:{
                                items: 1
                            }
                        },
                    })
                })
            });
        </script>
    </div>
    <?php
    return ob_get_clean();
}

add_shortcode('tz-carousel', 'aventura_carousel_slide');
?>