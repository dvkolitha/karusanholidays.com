<?php
if(function_exists('vc_map')):
    vc_map( array(
        "name"  => esc_html__("Carousel Slider", "aventura-plugin"),
        "weight" => 14,
        "base" => "tz-carousel",
        "icon" => "icon-element",
        "description" => "",
        "class" => "tzElement_extended",
        "category" => esc_html__("Aventura", "aventura-plugin"),
        "params" => array(
            array(
                'type'       => 'param_group',
                'param_name' => 'meta',
                'heading'    => esc_html__( 'List Meta', 'aventura-plugin' ),
                "group" => esc_html__( 'General', 'aventura-plugin' ),
                'params'     => array(
                    array(
                        'type'        => 'attach_image',
                        'param_name'  => 'tz_image',
                        "admin_label" => false,
                        "heading"       => esc_html__("Upload Image", "aventura-plugin"),
                        "description"   => esc_html__("Upload image image gallery. ", "aventura-plugin"),
                    ),
                    array(
                        "type" => "textfield",
                        "admin_label" => false,
                        "heading"       => esc_html__("Image Size", "aventura-plugin"),
                        "param_name"    => "tz_image_size",
                        "description"   => esc_html__("Enter image size. Example: thumbnail, medium, large, full or other sizes defined by current theme. Alternatively enter image size in pixels: 200x100 (Width x Height). Leave empty to use thumbnail size. If used slides per view, this will be used to define carousel wrapper size. ", "aventura-plugin"),
                        "value" => "",
                        "group" => esc_html__( 'General', 'aventura-plugin' ),
                    ),
                    array(
                        "type"       => "textfield",
                        "class" => "",
                        "admin_label" => true,
                        "heading"    => esc_html__("Title", "aventura-plugin"),
                        "param_name" => "title",
                        "value" => "",
                        "group" => esc_html__( 'General', 'aventura-plugin' ),
                    ),
                    array(
                        "type"       => "textfield",
                        "class" => "",
                        "admin_label" => false,
                        "heading"    => esc_html__("Title Button", "aventura-plugin"),
                        "param_name" => "tz_button",
                        "value" => "",
                        "group" => esc_html__( 'General', 'aventura-plugin' )
                    ),
                    array(
                        "type"       => "textfield",
                        "class" => "",
                        "admin_label" => false,
                        "heading"    => esc_html__("Button Link", "aventura-plugin"),
                        "param_name" => "tz_link",
                        "value" => "",
                        "group" => esc_html__( 'General', 'aventura-plugin' )
                    ),
                ),
            ),
            array(
                "type"       => "textfield",
                "class" => "",
                "admin_label" => true,
                "heading"    => __("Title Video", "aventura-plugin"),
                "param_name" => "title_video",
                "value" => "",
                "group" => esc_html__( 'General', 'aventura-plugin' ),
            ),

            array(
                "type"       => "textarea",
                "class" => "",
                "admin_label" => false,
                "heading"    => esc_html__("Video", "aventura-plugin"),
                "param_name" => "content",
                "value" => "",
                "group" => esc_html__( 'General', 'aventura-plugin' )
            ),

        )
    ) );


endif;
?>