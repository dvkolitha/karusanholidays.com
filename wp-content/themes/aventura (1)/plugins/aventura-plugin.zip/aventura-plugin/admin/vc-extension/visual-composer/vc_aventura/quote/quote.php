<?php
/*
 * Element tz-feature-item
 * */

function aventura__quote($atts, $content = null) {
    $tz_image = $tz_image_size = $tz_click_action = $tz_custom_links = $tz_link_target = '';
    $disme_marketing_params = '';
    extract(shortcode_atts(array(
        'tz_image'              => '',
        'disme_marketing_params'          =>  '',
        'tz_image_size'         => '',
        'tz_click_action'       => 'none',
        'tz_custom_links'       => '',
        'tz_link_target'        => 'same',

    ),$atts));
    ob_start();
    $disme_marketing_params = vc_param_group_parse_atts( $atts['disme_marketing_params'] );

    wp_enqueue_script( 'owl-carousel' );
    wp_enqueue_style( 'owl-carousel' );

    if ( 'link_image' === $tz_click_action ) {
        wp_enqueue_script( 'jquery.prettyPhoto' );
        wp_enqueue_style( 'prettyPhoto' );
    }

    $images = explode( ',', $tz_image );
    $pretty_rand = 'pretty' === $tz_click_action ? ' data-rel="prettyPhoto[rel-' . get_the_ID() . '-' . rand() . ']"' : '';

    if ( 'custom' === $tz_click_action ) {
        $custom_links = vc_value_from_safe( $tz_custom_links );
        $custom_links = explode( ',', $tz_custom_links );
    }

    $i = -1;
    ?>
    <div class="tzElement_quote">
        <?php
        foreach ( $images as $attach_id ) {
        $post_thumbnail = wpb_getImageBySize( array(
            'attach_id' => $attach_id,
            'thumb_size' => $tz_image_size,
        ) );
        $thumbnail = $post_thumbnail['thumbnail'];
        ?>
        <div class="tz-quote owl-carousel">
            <?php
            $i = 0;
            if(isset($disme_marketing_params) && $disme_marketing_params != ''):
            foreach ($disme_marketing_params as $params):
            $disme_marketing_author = $params["author"];
            $disme_marketing_content = $params["content"];
            $disme_marketing_image = $params["tz_image"];
            $disme_marketing_size = $params["tz_image_size"];
            $i++;

            ?>
                <div class="tzImage_Slide_Item">
                        <?php echo wp_get_attachment_image($disme_marketing_image, $disme_marketing_size) ?>
                            <div class="section">
                                    <div class="absotute-content">

                                        <?php if(isset($disme_marketing_content) && $disme_marketing_content != ''): ?>
                                            <p class="content"><?php echo balanceTags($disme_marketing_content); ?></p>
                                        <?php endif; ?>

                                        <?php if(isset($disme_marketing_author) && $disme_marketing_author != ''): ?>
                                            <h3 class="author"><?php echo balanceTags($disme_marketing_author); ?></h3>
                                        <?php endif; ?>

                                    </div>
                            </div>

                </div>
            <?php
            endforeach;
            endif;
            ?>
        </div>
        <?php } ?>
        <script type="text/javascript">
            jQuery(document).ready(function(){
                "use strict";

                jQuery( '.tz-quote').each(function(){

                    jQuery(this).owlCarousel({
                        nav:false,
                        navText:false,
                        dots:true,
                        animateIn: 'fadeIn',
                        animateOut: 'fadeOut',
                        slideSpeed : 1000,
                        loop: true,
                        paginationSpeed : 1000,
                        responsive:{
                            0:{
                                items: 1
                            },
                            600:{
                                items: 1
                            },
                            992:{
                                items: 1
                            },
                            1200:{
                                items: 1
                            }
                        },
                    })
                })
            });
        </script>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('tz-comment','aventura__quote');
?>